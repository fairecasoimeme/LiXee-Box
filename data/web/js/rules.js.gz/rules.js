// ============================================================
// rules.js - Shared rule editor logic for add/edit pages
// Served from LittleFS: /web/js/rules.js
// ============================================================

var devices = {}, templates = {};
var actionGroupsList = [];   // groupes d'actions, pour le type d'action "actiongroup"
var conditionCount = 0, actionCount = 0, elseActionCount = 0;
var devicesLoaded = false, templatesLoaded = false, groupsLoaded = false;

// Issue #31 : sous-champs du registre STGE (ZLinky, cluster FF66/65382, attribut 535).
// Comparer la chaine hex entiere casse des qu'un bit change ; on expose chaque champ de bits.
// key   = nom du sous-champ envoye au firmware (== table de getStatusRegisterFieldValue, C++).
// La comparaison porte sur la VALEUR NUMERIQUE du champ (masque + decalage) ; les libelles
// ci-dessous ne servent qu'a l'affichage (jamais compares -> accents sans risque).
var STGE_CLUSTER = 65382, STGE_ATTRIBUTE = 535;
var STGE_FIELDS = {
  'contact_sec':          { label: 'Contact sec',              opts: [[0, 'Ferm\u00e9'], [1, 'Ouvert']] },
  'organe_coupure':       { label: 'Organe de coupure',        opts: [[0, 'Ferm\u00e9'], [1, 'Surpuissance'], [2, 'Surtension'], [3, 'D\u00e9lestage'], [4, 'Ordre CPL/Euridis'], [5, 'Surchauffe (surcourant)'], [6, 'Surchauffe']] },
  'cache_borne_dist':     { label: 'Cache-borne distributeur', opts: [[0, 'Ferm\u00e9'], [1, 'Ouvert']] },
  'surtension_phase':     { label: 'Surtension sur une phase', opts: [[0, 'Non'], [1, 'Oui']] },
  'depassement_ref_pow':  { label: 'D\u00e9passement puiss. r\u00e9f.', opts: [[0, 'Non'], [1, 'Oui']] },
  'producteur':           { label: 'Producteur / conso.',      opts: [[0, 'Consommateur'], [1, 'Producteur']] },
  'sens_energie_active':  { label: 'Sens \u00e9nergie active', opts: [[0, 'Positive'], [1, 'N\u00e9gative']] },
  'tarif_four':           { label: 'Tarif fourniture (index)', opts: [] },   // rempli plus bas (16 index)
  'tarif_dist':           { label: 'Tarif distributeur (index)', opts: [] }, // rempli plus bas (4 index)
  'horloge':              { label: 'Horloge',                  opts: [[0, 'Correcte'], [1, 'D\u00e9grad\u00e9e']] },
  'type_tic':             { label: 'Type TIC',                 opts: [[0, 'Historique'], [1, 'Standard']] },
  'comm_euridis':         { label: 'Comm. Euridis',            opts: [[0, 'D\u00e9sactiv\u00e9e'], [1, 'Activ\u00e9e sans s\u00e9curit\u00e9'], [3, 'Activ\u00e9e avec s\u00e9curit\u00e9']] },
  'etat_cpl':             { label: '\u00c9tat CPL',           opts: [[0, 'Nouveau / d\u00e9verrouill\u00e9'], [1, 'Nouveau / verrouill\u00e9'], [2, 'Enregistr\u00e9']] },
  'sync_cpl':             { label: 'Synchro CPL',              opts: [[0, 'Non synchronis\u00e9'], [1, 'Synchronis\u00e9']] },
  'tempo_jour':           { label: 'Couleur Tempo (jour)',     opts: [[0, 'Inconnu'], [1, 'Bleu'], [2, 'Blanc'], [3, 'Rouge']] },
  'tempo_demain':         { label: 'Couleur Tempo (demain)',   opts: [[0, 'Inconnu'], [1, 'Bleu'], [2, 'Blanc'], [3, 'Rouge']] },
  'preavis_pointe_mobile':{ label: 'Pr\u00e9avis pointe mobile', opts: [[0, 'Aucun'], [1, 'PM1'], [2, 'PM2'], [3, 'PM3']] },
  'pointe_mobile':        { label: 'Pointe mobile',            opts: [[0, 'Aucun'], [1, 'PM1'], [2, 'PM2'], [3, 'PM3']] }
};
(function () {
  for (var i = 0; i < 16; i++) STGE_FIELDS.tarif_four.opts.push([i, 'Index ' + (i + 1)]);
  for (var j = 0; j < 4;  j++) STGE_FIELDS.tarif_dist.opts.push([j, 'Index ' + (j + 1)]);
})();

function hasSubfields(clDec, atDec) {
  return clDec === STGE_CLUSTER && atDec === STGE_ATTRIBUTE;
}

// Affiche/masque le select de propriete selon l'attribut, et le remplit pour STGE.
function refreshSubfieldSelect(id) {
  var c = $('[data-id="' + id + '"]');
  var clDec = parseInt(c.find('.cluster-select').val());
  var atDec = parseInt(c.find('.attribute-select').val());
  var col = c.find('.subfield-col'), sel = c.find('.subfield-select');
  if (!hasSubfields(clDec, atDec)) {
    col.hide();
    sel.html('<option value="">--</option>');
    onSubfieldChange(id);
    return;
  }
  var cur = sel.val();
  var html = '<option value="">(valeur brute)</option>';
  for (var k in STGE_FIELDS) { html += '<option value="' + k + '">' + STGE_FIELDS[k].label + '</option>'; }
  sel.html(html);
  if (cur) sel.val(cur);
  col.show();
  onSubfieldChange(id);
}

// Alimente les suggestions du champ Valeur : value = numero du champ, libelle affiche a cote.
function onSubfieldChange(id) {
  var c = $('[data-id="' + id + '"]');
  var f = c.find('.subfield-select').val();
  var dl = c.find('.subfield-datalist');
  if (f && STGE_FIELDS[f]) {
    var h = '';
    STGE_FIELDS[f].opts.forEach(function (o) { h += '<option value="' + o[0] + '">' + o[1] + '</option>'; });
    dl.html(h);
  } else {
    dl.html('');
  }
  if (typeof buildRuleSummary === 'function') buildRuleSummary();
}

var clusterNames = {
  '0000':'Basic','0001':'Power','0003':'Identify','0004':'Groups',
  '0005':'Scenes','0006':'On/Off','0008':'Level Control','000A':'Time',
  '0019':'OTA Upgrade','0020':'Poll Control','0100':'Shade Config',
  '0101':'Door Lock','0102':'Window Covering','0201':'Thermostat',
  '0202':'Fan Control','0300':'Color Control','0400':'Illuminance',
  '0402':'Temperature','0403':'Pressure','0405':'Humidity',
  '0406':'Occupancy','0500':'IAS Zone','0502':'IAS WD',
  '0702':'Simple Metering','0B04':'Electrical Measurement',
  '0B05':'Diagnostics','1000':'Touchlink','EF00':'Tuya',
  'FC11':'Sonoff Custom','FF66':'LiXee'
};

function clusterLabel(hex) {
  var n = clusterNames[hex];
  return n ? '0x' + hex + ' - ' + n : '0x' + hex;
}

// ========== HELPERS ==========

function getDeviceLabel(ieee) {
  if (!ieee || !devices[ieee] || !devices[ieee].INFO) return ieee || '?';
  var info = devices[ieee].INFO;
  if (info.alias && info.alias !== 'null' && info.alias.length > 0) return info.alias;
  if (info.model && info.model !== 'null' && info.model.length > 0) return info.model;
  return ieee;
}

function getTemplateData(ieee) {
  if (!ieee || !devices[ieee] || !devices[ieee].INFO) return null;
  var dev = devices[ieee];
  var tid = dev.INFO.device_id, m = dev.INFO.model || 'default';
  var tk = tid + '.json', tf = templates[tk];
  if (!tf) return null;
  return tf[m] || tf['default'] || null;
}

function getTemplateStatusItem(ieee, clusterDec, attributeDec) {
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return null;
  var clHex = ('0000' + clusterDec.toString(16).toUpperCase()).slice(-4);
  for (var i = 0; i < td[0].status.length; i++) {
    var item = td[0].status[i];
    if (item.cluster.toUpperCase() === clHex && parseInt(item.attribut) === attributeDec) {
      return item;
    }
  }
  return null;
}

function getCurrentSensorValue(ieee, clusterDec, attributeDec) {
  if (!ieee || !devices[ieee]) return null;
  var dev = devices[ieee];
  var clHex = ('0000' + clusterDec.toString(16).toUpperCase()).slice(-4);
  var attrStr = String(attributeDec);
  if (!dev[clHex]) return null;
  var rawVal = dev[clHex][attrStr];
  if (rawVal === undefined || rawVal === null) return null;

  var tplItem = getTemplateStatusItem(ieee, clusterDec, attributeDec);
  var coefficient = (tplItem && tplItem.coefficient) ? tplItem.coefficient : 1;
  var unit = (tplItem && tplItem.unit) ? tplItem.unit : '';

  var numVal = parseInt(rawVal, 16);
  if (!isNaN(numVal)) {
    var displayVal = numVal * coefficient;
    var formatted = (coefficient === 1) ? String(Math.round(displayVal)) : displayVal.toFixed(2);
    return { value: formatted, unit: unit, raw: rawVal };
  }
  return { value: rawVal, unit: '', raw: rawVal };
}

function getAttributeName(ieee, clusterDec, attributeDec) {
  var item = getTemplateStatusItem(ieee, clusterDec, attributeDec);
  if (item && item.name) return item.name;
  return 'attr.' + attributeDec;
}

function getDeviceActions(ieee) {
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].action) return [];
  return td[0].action;
}

function hasCluster0006(ieee) {
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return false;
  return td[0].status.some(function(item) { return item.cluster.toUpperCase() === '0006'; });
}

// ========== INIT ==========

function initRulesEditor(mode, ruleData) {
  $.get('/getDevices', function(d) { devices = d; devicesLoaded = true; checkDataLoadedAndInit(mode, ruleData); });
  $.get('/getTemplates', function(d) { templates = d; templatesLoaded = true; checkDataLoadedAndInit(mode, ruleData); });
  // Les groupes d'actions ne doivent jamais BLOQUER l'editeur : on marque le chargement
  // termine meme en cas d'echec (always), la liste sera simplement vide.
  $.get('/api/actiongroups/list')
    .done(function(d) { actionGroupsList = (d && d.groups) || []; })
    .always(function() { groupsLoaded = true; checkDataLoadedAndInit(mode, ruleData); });
}

function checkDataLoadedAndInit(mode, ruleData) {
  if (!devicesLoaded || !templatesLoaded || !groupsLoaded) return;
  populateTriggerDeviceSelect();
  if (mode === 'edit' && ruleData) {
    loadRule(ruleData);
  } else {
    addCondition();
    addAction();
  }
  // Delegated event listener for live summary update
  $('#ruleForm').on('change input', 'select, input', function() {
    clearTimeout(window._summaryTimer);
    window._summaryTimer = setTimeout(buildRuleSummary, 200);
  });
  setTimeout(buildRuleSummary, 300);
  updateModeInfo();
}

function setupSubmitHandler(mode) {
  $('#ruleForm').on('submit', function(e) {
    e.preventDefault();
    var rule = {
      name: $('#ruleName').val(),
      enabled: $('#ruleEnabled').is(':checked'),
      trigger: {
        mode: $('#triggerMode').val(),
        IEEE: $('#triggerDevice').val() || '',
        cluster: parseInt($('#triggerCluster').val()) || 0,
        attribute: parseInt($('#triggerAttribute').val()) || 0
      },
      conditions: [], actions: [], elseActions: [],
      duration: (parseInt($('#ruleDuration').val()) || 0) * 60,
      repeat: $('#ruleRepeat').val() === '1',
      cooldown: (parseInt($('#ruleCooldown').val()) || 0) * 60,
      maxExecPerDay: parseInt($('#ruleMaxExecPerDay').val()) || 0
    };
    if (mode === 'edit') {
      rule.oldName = $('#oldRuleName').val();
    }
    $('.condition-item').each(function() { rule.conditions.push(collectConditionData($(this))); });
    if (rule.conditions.length === 0) { alert('Ajoutez au moins une condition'); return false; }
    $('.action-item').each(function() {
      var c = $(this), t = c.find('.action-type-select').val(), a = { type: t };
      if (t === 'device') { a.IEEE = c.find('.action-device-select').val(); a.actionName = c.find('.action-name-select').val(); a.endpoint = parseInt(c.find('.action-device-endpoint-input').val()) || 1; a.value = ''; a.title = ''; a.message = ''; }
      else if (t === 'onoff') { a.IEEE = c.find('.action-legacy-device-select').val(); a.endpoint = parseInt(c.find('.action-endpoint-input').val()) || 1; a.value = c.find('.action-value-select').val(); a.actionName = ''; a.title = ''; a.message = ''; }
      else if (t === 'dynamic') { a.IEEE = c.find('.action-device-select').val(); a.actionName = c.find('.action-name-select').val(); a.endpoint = parseInt(c.find('.action-device-endpoint-input').val()) || 1; a.sourceIEEE = c.find('.action-source-device-select').val(); a.sourceCluster = parseInt(c.find('.action-source-cluster-select').val()) || 0; a.sourceAttribute = parseInt(c.find('.action-source-attribute-select').val()) || 0; a.coefficient = parseFloat(c.find('.action-coefficient-input').val()) || 1; a.offset = parseFloat(c.find('.action-offset-input').val()) || 0; a.value = ''; a.title = ''; a.message = ''; }
      else if (t === 'actiongroup') { a.IEEE = ''; a.actionName = c.find('.action-group-select').val(); a.endpoint = 0; a.value = ''; a.title = ''; a.message = ''; }
      else { a.IEEE = ''; a.actionName = ''; a.endpoint = 0; a.value = ''; a.title = c.find('.action-title-input').val(); a.message = c.find('.action-message-input').val(); }
      rule.actions.push(a);
    });
    $('.else-action-item').each(function() {
      var c = $(this), t = c.find('.else-action-type-select').val(), a = { type: t };
      if (t === 'device') { a.IEEE = c.find('.else-action-device-select').val(); a.actionName = c.find('.else-action-name-select').val(); a.endpoint = parseInt(c.find('.else-action-device-endpoint-input').val()) || 1; a.value = ''; a.title = ''; a.message = ''; }
      else if (t === 'onoff') { a.IEEE = c.find('.else-action-legacy-device-select').val(); a.endpoint = parseInt(c.find('.else-action-endpoint-input').val()) || 1; a.value = c.find('.else-action-value-select').val(); a.actionName = ''; a.title = ''; a.message = ''; }
      else if (t === 'dynamic') { a.IEEE = c.find('.else-action-device-select').val(); a.actionName = c.find('.else-action-name-select').val(); a.endpoint = parseInt(c.find('.else-action-device-endpoint-input').val()) || 1; a.sourceIEEE = c.find('.else-action-source-device-select').val(); a.sourceCluster = parseInt(c.find('.else-action-source-cluster-select').val()) || 0; a.sourceAttribute = parseInt(c.find('.else-action-source-attribute-select').val()) || 0; a.coefficient = parseFloat(c.find('.else-action-coefficient-input').val()) || 1; a.offset = parseFloat(c.find('.else-action-offset-input').val()) || 0; a.value = ''; a.title = ''; a.message = ''; }
      else if (t === 'actiongroup') { a.IEEE = ''; a.actionName = c.find('.else-action-group-select').val(); a.endpoint = 0; a.value = ''; a.title = ''; a.message = ''; }
      else { a.IEEE = ''; a.actionName = ''; a.endpoint = 0; a.value = ''; a.title = c.find('.else-action-title-input').val(); a.message = c.find('.else-action-message-input').val(); }
      rule.elseActions.push(a);
    });
    var url = (mode === 'edit') ? '/api/rules/edit' : '/api/rules/add';
    var msg = (mode === 'edit') ? 'R\u00e8gle modifi\u00e9e !' : 'R\u00e8gle cr\u00e9\u00e9e !';
    $.ajax({ url: url, type: 'POST', contentType: 'application/json', data: JSON.stringify(rule),
      success: function() { alert(msg); window.location.href = '/configRules'; },
      error: function(xhr) { alert('Erreur : ' + xhr.responseText); }
    });
  });
}

// ========== TRIGGER ==========

function populateTriggerDeviceSelect() {
  var s = $('#triggerDevice').html('<option value="">-- Choisir --</option>');
  $.each(devices, function(ieee, dev) {
    if (dev.INFO) {
      var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee + ')';
      s.append('<option value="' + ieee + '">' + l + '</option>');
    }
  });
}

function onTriggerModeChange() {
  var mode = $('#triggerMode').val();
  if (mode === 'event') { $('.trigger-event-fields').show(); $('#triggerDevice,#triggerCluster,#triggerAttribute').prop('required', true); }
  else { $('.trigger-event-fields').hide(); $('#triggerDevice,#triggerCluster,#triggerAttribute').prop('required', false); }
}

function onTriggerDeviceChange() {
  var ieee = $('#triggerDevice').val(), c = $('#triggerCluster'), a = $('#triggerAttribute');
  c.html('<option value="">-- Cluster --</option>'); a.html('<option value="">-- Attribut --</option>');
  if (!ieee || !devices[ieee] || !devices[ieee].INFO) return;
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  var clAdded = {};
  td[0].status.forEach(function(item) {
    var clStr = item.cluster.toUpperCase();
    if (!clAdded[clStr]) { c.append('<option value="' + parseInt(clStr, 16) + '">' + clusterLabel(clStr) + '</option>'); clAdded[clStr] = true; }
  });
}

function onTriggerClusterChange() {
  var ieee = $('#triggerDevice').val(), cl = parseInt($('#triggerCluster').val()), a = $('#triggerAttribute');
  a.html('<option value="">-- Attribut --</option>');
  if (!ieee || !cl) return;
  var clHex = ('0000' + cl.toString(16).toUpperCase()).slice(-4);
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  td[0].status.forEach(function(item) {
    if (item.cluster.toUpperCase() === clHex) {
      var aid = item.attribut, an = item.name || aid;
      a.append('<option value="' + aid + '">' + an + ' (' + aid + ')</option>');
    }
  });
}

// ========== CONDITIONS ==========

function addCondition(data) {
  var id = conditionCount++;
  var type = data ? data.type || 'device' : 'device';

  // Logic separator BETWEEN conditions (not for the first one)
  if ($('#conditionsContainer .condition-item').length > 0) {
    var logicVal = data ? (data.logic || 'AND') : 'AND';
    var sepHtml = '<div class="logic-separator d-flex align-items-center justify-content-center my-1" data-for-condition="' + id + '">' +
      '<hr class="flex-grow-1 m-0">' +
      '<select class="form-select form-select-sm logic-select mx-2" style="width:auto;font-weight:bold;" onchange="buildRuleSummary()">' +
      '<option value="AND"' + (logicVal === 'AND' ? ' selected' : '') + '>ET (AND)</option>' +
      '<option value="OR"' + (logicVal === 'OR' ? ' selected' : '') + '>OU (OR)</option>' +
      '</select>' +
      '<hr class="flex-grow-1 m-0">' +
      '</div>';
    $('#conditionsContainer').append(sepHtml);
  }

  var html = '<div class="card mb-2 condition-item" data-id="' + id + '"><div class="card-body">' +
    '<div class="row g-2">' +
    '<div class="col-md-3"><label class="form-label small">Type</label>' +
    '<select class="form-select form-select-sm condition-type-select" onchange="onConditionTypeChange(' + id + ')" required>' +
    '<option value="device"' + (type === 'device' ? ' selected' : '') + '>Appareil Zigbee</option>' +
    '<option value="device_compare"' + (type === 'device_compare' ? ' selected' : '') + '>Comparer 2 appareils</option>' +
    '<option value="time"' + (type === 'time' ? ' selected' : '') + '>Heure pr\u00e9cise</option>' +
    '<option value="time_range"' + (type === 'time_range' ? ' selected' : '') + '>Plage horaire</option>' +
    '<option value="weekday"' + (type === 'weekday' ? ' selected' : '') + '>Jour de semaine</option>' +
    '<option value="date"' + (type === 'date' ? ' selected' : '') + '>Date</option>' +
    '<option value="datetime"' + (type === 'datetime' ? ' selected' : '') + '>Date et heure</option>' +
    '<option value="day"' + (type === 'day' ? ' selected' : '') + '>Jour du mois</option>' +
    '<option value="month"' + (type === 'month' ? ' selected' : '') + '>Mois</option>' +
    '</select></div>' +
    '<div class="col-md-8 condition-fields-wrapper"></div>' +
    '<div class="col-md-1 d-flex align-items-end"><button type="button" class="btn btn-sm btn-danger" onclick="removeCondition(' + id + ')">\u00d7</button></div>' +
    '</div>' +
    '</div></div>';
  $('#conditionsContainer').append(html);
  onConditionTypeChange(id);
  if (data) {
    var c = $('[data-id="' + id + '"]');
    setTimeout(function() { loadConditionData(c, data); }, 50);
  }
}

function onConditionTypeChange(id) {
  var c = $('[data-id="' + id + '"]'), type = c.find('.condition-type-select').val();
  var wrapper = c.find('.condition-fields-wrapper');
  wrapper.html(getConditionFieldsHTML(type, id));
  if (type === 'device' || type === 'device_compare') {
    c.find('.device-select, .device2-select').each(function() {
      var sel = $(this);
      $.each(devices, function(ieee, dev) {
        if (dev.INFO) {
          var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee + ')';
          sel.append('<option value="' + ieee + '">' + l + '</option>');
        }
      });
    });
  }
  buildRuleSummary();
}

function getConditionFieldsHTML(type, id) {
  switch (type) {
    case 'time':
      return '<div class="row g-2"><div class="col-md-4"><label class="form-label small">Heure</label><input type="time" class="form-control form-control-sm time-input" value="08:00" required></div><div class="col-md-4"><label class="form-label small">Op\u00e9rateur</label><select class="form-select form-select-sm operator-select" required><option value="==">= (\u00e9gal)</option><option value="!=">&#8800; (diff\u00e9rent)</option><option value="<">&lt; (avant)</option><option value="<=">&le;</option><option value=">">&gt; (apr\u00e8s)</option><option value=">=">&ge;</option></select></div></div>';
    case 'time_range':
      return '<div class="row g-2"><div class="col-md-3"><label class="form-label small">De</label><input type="time" class="form-control form-control-sm time-start-input" value="08:00" required></div><div class="col-md-3"><label class="form-label small">\u00c0</label><input type="time" class="form-control form-control-sm time-end-input" value="18:00" required></div><div class="col-md-3"><label class="form-label small">Op\u00e9rateur</label><select class="form-select form-select-sm operator-select" required><option value="in">Dans la plage</option><option value="not_in">Hors plage</option></select></div></div>';
    case 'weekday':
      return '<div class="row g-2"><div class="col-md-8"><label class="form-label small">Jours</label><div class="btn-group btn-group-sm d-flex flex-wrap">' +
        '<input type="checkbox" class="btn-check weekday-check" id="wd-' + id + '-1" value="1"><label class="btn btn-outline-primary" for="wd-' + id + '-1">Lun</label>' +
        '<input type="checkbox" class="btn-check weekday-check" id="wd-' + id + '-2" value="2"><label class="btn btn-outline-primary" for="wd-' + id + '-2">Mar</label>' +
        '<input type="checkbox" class="btn-check weekday-check" id="wd-' + id + '-3" value="3"><label class="btn btn-outline-primary" for="wd-' + id + '-3">Mer</label>' +
        '<input type="checkbox" class="btn-check weekday-check" id="wd-' + id + '-4" value="4"><label class="btn btn-outline-primary" for="wd-' + id + '-4">Jeu</label>' +
        '<input type="checkbox" class="btn-check weekday-check" id="wd-' + id + '-5" value="5"><label class="btn btn-outline-primary" for="wd-' + id + '-5">Ven</label>' +
        '<input type="checkbox" class="btn-check weekday-check" id="wd-' + id + '-6" value="6"><label class="btn btn-outline-primary" for="wd-' + id + '-6">Sam</label>' +
        '<input type="checkbox" class="btn-check weekday-check" id="wd-' + id + '-7" value="7"><label class="btn btn-outline-primary" for="wd-' + id + '-7">Dim</label>' +
        '</div></div><div class="col-md-3"><label class="form-label small">Op.</label><select class="form-select form-select-sm operator-select" required><option value="in">Ces jours</option><option value="not_in">Sauf ces jours</option></select></div></div>';
    case 'date':
      return '<div class="row g-2"><div class="col-md-4"><label class="form-label small">Date</label><input type="date" class="form-control form-control-sm date-input" required></div><div class="col-md-3"><label class="form-label small">Op\u00e9rateur</label><select class="form-select form-select-sm operator-select" required><option value="==">= ce jour</option><option value="!=">&#8800; pas ce jour</option><option value="<">&lt; avant</option><option value=">">&gt; apr\u00e8s</option></select></div><div class="col-md-3 d-flex align-items-end"><div class="form-check"><input class="form-check-input ignore-year-check" type="checkbox" checked id="iy-' + id + '"><label class="form-check-label small" for="iy-' + id + '">R\u00e9current (ignorer ann\u00e9e)</label></div></div></div>';
    case 'day':
      return '<div class="row g-2"><div class="col-md-4"><label class="form-label small">Jour du mois</label><input type="number" class="form-control form-control-sm day-input" min="1" max="31" value="1" required></div><div class="col-md-4"><label class="form-label small">Op\u00e9rateur</label><select class="form-select form-select-sm operator-select" required><option value="==">= \u00e9gal</option><option value="!=">&#8800; diff\u00e9rent</option><option value="<">&lt;</option><option value=">">&gt;</option></select></div></div>';
    case 'month':
      return '<div class="row g-2"><div class="col-md-4"><label class="form-label small">Mois</label><select class="form-select form-select-sm month-input" required><option value="1">Janvier</option><option value="2">F\u00e9vrier</option><option value="3">Mars</option><option value="4">Avril</option><option value="5">Mai</option><option value="6">Juin</option><option value="7">Juillet</option><option value="8">Ao\u00fbt</option><option value="9">Septembre</option><option value="10">Octobre</option><option value="11">Novembre</option><option value="12">D\u00e9cembre</option></select></div><div class="col-md-4"><label class="form-label small">Op\u00e9rateur</label><select class="form-select form-select-sm operator-select" required><option value="==">= \u00e9gal</option><option value="!=">&#8800; diff\u00e9rent</option></select></div></div>';
    case 'datetime':
      return '<div class="row g-2"><div class="col-md-3"><label class="form-label small">Date</label><input type="date" class="form-control form-control-sm datetime-date-input" required></div><div class="col-md-2"><label class="form-label small">Heure</label><input type="time" class="form-control form-control-sm datetime-time-input" value="08:00" required></div><div class="col-md-3"><label class="form-label small">Op\u00e9rateur</label><select class="form-select form-select-sm operator-select" required><option value="==">= exactement</option><option value="!=">&#8800; diff\u00e9rent</option><option value="<">&lt; avant</option><option value=">">&gt; apr\u00e8s</option></select></div></div>';
    case 'device_compare':
      return '<div class="row g-2 mb-2">' +
        '<div class="col-5"><label class="form-label small">Appareil 1</label><select class="form-select form-select-sm device-select" onchange="onDeviceChange(' + id + ')" required><option value="">-- Choisir --</option></select></div>' +
        '<div class="col-4"><label class="form-label small">Cluster</label><select class="form-select form-select-sm cluster-select" onchange="onClusterChange(' + id + ')" required><option value="">--</option></select></div>' +
        '<div class="col-3"><label class="form-label small">Attribut</label><select class="form-select form-select-sm attribute-select" onchange="updateCurrentValueDisplay(' + id + ')" required><option value="">--</option></select><span class="current-value-badge" style="display:none;font-size:0.75em;color:#2e7d32;font-weight:500;"></span></div>' +
        '</div>' +
        '<div class="row g-2 mb-2">' +
        '<div class="col-3"><label class="form-label small">Op\u00e9rateur</label><select class="form-select form-select-sm operator-select" required><option value=">">&gt; sup\u00e9rieur(e)</option><option value=">=">&ge; sup. ou \u00e9gal(e)</option><option value="<">&lt; inf\u00e9rieur(e)</option><option value="<=">&le; inf. ou \u00e9gal(e)</option><option value="==">== \u00e9gal</option><option value="!=">!= diff\u00e9rent</option></select></div>' +
        '<div class="col-3"><label class="form-label small">Offset</label><input type="number" class="form-control form-control-sm value-input" step="any" value="" placeholder="ex: 2"></div>' +
        '</div>' +
        '<div class="row g-2">' +
        '<div class="col-5"><label class="form-label small">Appareil 2</label><select class="form-select form-select-sm device2-select" onchange="onDevice2Change(' + id + ')" required><option value="">-- Choisir --</option></select></div>' +
        '<div class="col-4"><label class="form-label small">Cluster</label><select class="form-select form-select-sm cluster2-select" onchange="onCluster2Change(' + id + ')" required><option value="">--</option></select></div>' +
        '<div class="col-3"><label class="form-label small">Attribut</label><select class="form-select form-select-sm attribute2-select" onchange="updateCurrentValueDisplay2(' + id + ')" required><option value="">--</option></select><span class="current-value-badge2" style="display:none;font-size:0.75em;color:#2e7d32;font-weight:500;"></span></div>' +
        '</div>';
    case 'device':
    default:
      return '<div class="row g-2">' +
        '<div class="col-md-3"><label class="form-label small">Appareil</label><select class="form-select form-select-sm device-select" onchange="onDeviceChange(' + id + ')" required><option value="">-- Choisir --</option></select></div>' +
        '<div class="col-md-2"><label class="form-label small">Cluster</label><select class="form-select form-select-sm cluster-select" onchange="onClusterChange(' + id + ')" required><option value="">--</option></select></div>' +
        '<div class="col-md-2"><label class="form-label small">Attribut</label><select class="form-select form-select-sm attribute-select" onchange="updateCurrentValueDisplay(' + id + ')" required><option value="">--</option></select></div>' +
        '<div class="col-md-2 subfield-col" style="display:none"><label class="form-label small">Propri\u00e9t\u00e9</label><select class="form-select form-select-sm subfield-select" onchange="onSubfieldChange(' + id + ')"><option value="">--</option></select></div>' +
        '<div class="col-md-1"><label class="form-label small">Op.</label><select class="form-select form-select-sm operator-select" onchange="onOperatorChange(' + id + ')" required><option value="==">==</option><option value="!=">!=</option><option value="<">&lt;</option><option value="<=">&le;</option><option value=">">&gt;</option><option value=">=">&ge;</option></select></div>' +
        '<div class="col-md-2"><label class="form-label small">Valeur</label><input type="text" class="form-control form-control-sm value-input" list="subfield-dl-' + id + '" required><datalist class="subfield-datalist" id="subfield-dl-' + id + '"></datalist><span class="current-value-badge" style="display:none;font-size:0.75em;color:#2e7d32;font-weight:500;"></span></div>' +
        '</div>';
  }
}

function loadConditionData(c, data) {
  var type = data.type || 'device';
  c.find('.operator-select').val(data.operator || '==');
  switch (type) {
    case 'time': c.find('.time-input').val(data.value || '08:00'); break;
    case 'time_range': c.find('.time-start-input').val(data.value || '08:00'); c.find('.time-end-input').val(data.value2 || '18:00'); break;
    case 'weekday': if (data.value) { data.value.split(',').forEach(function(d) { c.find('.weekday-check[value="' + d.trim() + '"]').prop('checked', true); }); } break;
    case 'date':
      if (data.value) {
        var p = data.value.split('/');
        if (p.length >= 2) {
          var y = p.length === 3 ? p[2] : new Date().getFullYear();
          c.find('.date-input').val(y + '-' + p[1].padStart(2, '0') + '-' + p[0].padStart(2, '0'));
          c.find('.ignore-year-check').prop('checked', p.length === 2);
        }
      }
      break;
    case 'day': c.find('.day-input').val(data.value || '1'); break;
    case 'month': c.find('.month-input').val(data.value || '1'); break;
    case 'datetime':
      if (data.value) {
        var parts = data.value.split(' ');
        if (parts.length === 2) {
          var dp = parts[0].split('/');
          if (dp.length === 3) c.find('.datetime-date-input').val(dp[2] + '-' + dp[1].padStart(2, '0') + '-' + dp[0].padStart(2, '0'));
          c.find('.datetime-time-input').val(parts[1]);
        }
      }
      break;
    case 'device_compare':
      c.find('.device-select').val(data.IEEE);
      onDeviceChange(parseInt(c.attr('data-id')));
      setTimeout(function() {
        c.find('.cluster-select').val(data.cluster);
        onClusterChange(parseInt(c.attr('data-id')));
        setTimeout(function() {
          c.find('.attribute-select').val(data.attribute);
          updateCurrentValueDisplay(parseInt(c.attr('data-id')));
        }, 100);
      }, 100);
      c.find('.device2-select').val(data.IEEE2);
      onDevice2Change(parseInt(c.attr('data-id')));
      setTimeout(function() {
        c.find('.cluster2-select').val(data.cluster2);
        onCluster2Change(parseInt(c.attr('data-id')));
        setTimeout(function() {
          c.find('.attribute2-select').val(data.attribute2);
          updateCurrentValueDisplay2(parseInt(c.attr('data-id')));
        }, 100);
      }, 100);
      if (data.value) c.find('.value-input').val(data.value);
      break;
    case 'device':
    default:
      c.find('.device-select').val(data.IEEE);
      onDeviceChange(parseInt(c.attr('data-id')));
      setTimeout(function() {
        c.find('.cluster-select').val(data.cluster);
        onClusterChange(parseInt(c.attr('data-id')));
        setTimeout(function() {
          c.find('.attribute-select').val(data.attribute);
          refreshSubfieldSelect(parseInt(c.attr('data-id')));
          if (data.subfield) { c.find('.subfield-select').val(data.subfield); onSubfieldChange(parseInt(c.attr('data-id'))); }
          c.find('.value-input').val(data.value);
          onOperatorChange(parseInt(c.attr('data-id')));
          updateCurrentValueDisplay(parseInt(c.attr('data-id')));
        }, 100);
      }, 100);
      break;
  }
}

function onOperatorChange(id) {
  var c = $('[data-id="' + id + '"]'), op = c.find('.operator-select').val(), v = c.find('.value-input');
  if (op === '==' || op === '!=') { v.attr('type', 'text').attr('placeholder', 'Texte ou nombre'); }
  else { v.attr('type', 'number').attr('placeholder', ''); if (v.val() && isNaN(v.val())) v.val(''); }
}

function onDeviceChange(id) {
  var c = $('[data-id="' + id + '"]'), ieee = c.find('.device-select').val(), clSel = c.find('.cluster-select');
  clSel.html('<option value="">--</option>');
  c.find('.attribute-select').html('<option value="">--</option>');
  c.find('.current-value-badge').hide().text('');
  if (!ieee || !devices[ieee] || !devices[ieee].INFO) return;
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  var clAdded = {};
  td[0].status.forEach(function(item) {
    var clStr = item.cluster.toUpperCase();
    if (!clAdded[clStr]) { clSel.append('<option value="' + parseInt(clStr, 16) + '">' + clusterLabel(clStr) + '</option>'); clAdded[clStr] = true; }
  });
}

function onClusterChange(id) {
  var c = $('[data-id="' + id + '"]'), ieee = c.find('.device-select').val(), clDec = parseInt(c.find('.cluster-select').val()), a = c.find('.attribute-select');
  a.html('<option value="">--</option>');
  c.find('.current-value-badge').hide().text('');
  if (!ieee || !devices[ieee] || !devices[ieee].INFO || !clDec) return;
  var clHex = ('0000' + clDec.toString(16).toUpperCase()).slice(-4);
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  td[0].status.forEach(function(item) {
    if (item.cluster.toUpperCase() === clHex) {
      var aid = item.attribut, an = item.name || aid;
      a.append('<option value="' + aid + '">' + an + ' (' + aid + ')</option>');
    }
  });
  updateCurrentValueDisplay(id);
}

function onDevice2Change(id) {
  var c = $('[data-id="' + id + '"]'), ieee = c.find('.device2-select').val(), clSel = c.find('.cluster2-select');
  clSel.html('<option value="">--</option>');
  c.find('.attribute2-select').html('<option value="">--</option>');
  c.find('.current-value-badge2').hide().text('');
  if (!ieee || !devices[ieee] || !devices[ieee].INFO) return;
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  var clAdded = {};
  td[0].status.forEach(function(item) {
    var clStr = item.cluster.toUpperCase();
    if (!clAdded[clStr]) { clSel.append('<option value="' + parseInt(clStr, 16) + '">' + clusterLabel(clStr) + '</option>'); clAdded[clStr] = true; }
  });
}

function onCluster2Change(id) {
  var c = $('[data-id="' + id + '"]'), ieee = c.find('.device2-select').val(), clDec = parseInt(c.find('.cluster2-select').val()), a = c.find('.attribute2-select');
  a.html('<option value="">--</option>');
  c.find('.current-value-badge2').hide().text('');
  if (!ieee || !devices[ieee] || !devices[ieee].INFO || !clDec) return;
  var clHex = ('0000' + clDec.toString(16).toUpperCase()).slice(-4);
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  td[0].status.forEach(function(item) {
    if (item.cluster.toUpperCase() === clHex) {
      var aid = item.attribut, an = item.name || aid;
      a.append('<option value="' + aid + '">' + an + ' (' + aid + ')</option>');
    }
  });
  updateCurrentValueDisplay2(id);
}

function updateCurrentValueDisplay(id) {
  var c = $('[data-id="' + id + '"]');
  refreshSubfieldSelect(id);
  var ieee = c.find('.device-select').val();
  var clDec = parseInt(c.find('.cluster-select').val());
  var atDec = parseInt(c.find('.attribute-select').val());
  var badge = c.find('.current-value-badge');
  if (!ieee || !clDec || isNaN(atDec)) { badge.hide().text(''); return; }
  var sv = getCurrentSensorValue(ieee, clDec, atDec);
  if (sv) { badge.text('Actuel: ' + sv.value + (sv.unit ? ' ' + sv.unit : '')).show(); }
  else { badge.text('--').show(); }
  buildRuleSummary();
}

function updateCurrentValueDisplay2(id) {
  var c = $('[data-id="' + id + '"]');
  var ieee = c.find('.device2-select').val();
  var clDec = parseInt(c.find('.cluster2-select').val());
  var atDec = parseInt(c.find('.attribute2-select').val());
  var badge = c.find('.current-value-badge2');
  if (!ieee || !clDec || isNaN(atDec)) { badge.hide().text(''); return; }
  var sv = getCurrentSensorValue(ieee, clDec, atDec);
  if (sv) { badge.text('Actuel: ' + sv.value + (sv.unit ? ' ' + sv.unit : '')).show(); }
  else { badge.text('--').show(); }
}

function removeCondition(id) {
  $('[data-for-condition="' + id + '"]').remove();
  $('[data-id="' + id + '"]').remove();
  // If the first element is now a separator (orphaned), remove it
  var first = $('#conditionsContainer').children().first();
  if (first.hasClass('logic-separator')) first.remove();
  buildRuleSummary();
}

function collectConditionData(c) {
  var type = c.find('.condition-type-select').val(), op = c.find('.operator-select').val();
  var id = c.attr('data-id');
  var sep = $('[data-for-condition="' + id + '"]');
  var logic = sep.length > 0 ? sep.find('.logic-select').val() : 'AND';
  var cond = { type: type, operator: op, logic: logic, IEEE: '', cluster: 0, attribute: 0, value: '', value2: '' };
  switch (type) {
    case 'time': cond.value = c.find('.time-input').val(); break;
    case 'time_range': cond.value = c.find('.time-start-input').val(); cond.value2 = c.find('.time-end-input').val(); break;
    case 'weekday': var days = []; c.find('.weekday-check:checked').each(function() { days.push($(this).val()); }); cond.value = days.join(','); break;
    case 'date':
      var dv = c.find('.date-input').val();
      if (dv) { var p = dv.split('-'); var iy = c.find('.ignore-year-check').is(':checked'); cond.value = iy ? p[2] + '/' + p[1] : p[2] + '/' + p[1] + '/' + p[0]; }
      break;
    case 'day': cond.value = c.find('.day-input').val(); break;
    case 'month': cond.value = c.find('.month-input').val(); break;
    case 'datetime':
      var dtDate = c.find('.datetime-date-input').val();
      var dtTime = c.find('.datetime-time-input').val() || '00:00';
      if (dtDate) { var dp = dtDate.split('-'); cond.value = dp[2] + '/' + dp[1] + '/' + dp[0] + ' ' + dtTime; }
      break;
    case 'device_compare':
      cond.IEEE = c.find('.device-select').val(); cond.cluster = parseInt(c.find('.cluster-select').val()) || 0;
      cond.attribute = parseInt(c.find('.attribute-select').val()) || 0;
      cond.IEEE2 = c.find('.device2-select').val(); cond.cluster2 = parseInt(c.find('.cluster2-select').val()) || 0;
      cond.attribute2 = parseInt(c.find('.attribute2-select').val()) || 0;
      cond.value = c.find('.value-input').val() || '';
      break;
    case 'device': default:
      cond.IEEE = c.find('.device-select').val(); cond.cluster = parseInt(c.find('.cluster-select').val()) || 0;
      cond.attribute = parseInt(c.find('.attribute-select').val()) || 0; cond.value = c.find('.value-input').val(); cond.subfield = c.find('.subfield-select').val() || '';
      break;
  }
  return cond;
}

// ========== ACTIONS ==========

function addAction(data) {
  var id = actionCount++;
  var html = '<div class="card mb-2 action-item" data-action-id="' + id + '"><div class="card-body"><div class="row g-2">' +
    '<div class="col-md-2"><label class="form-label small">Type</label>' +
    '<select class="form-select form-select-sm action-type-select" onchange="onActionTypeChange(' + id + ')" required>' +
    '<option value="device">Appareil</option><option value="dynamic">Valeur dynamique</option><option value="actiongroup">Groupe d&#39;actions</option><option value="notification">Notification</option></select></div>' +
    '<div class="col-md-3 action-device-fields"><label class="form-label small">Appareil</label>' +
    '<select class="form-select form-select-sm action-device-select" onchange="onActionDeviceChange(' + id + ')"><option value="">-- Choisir --</option></select></div>' +
    '<div class="col-md-3 action-device-fields"><label class="form-label small">Action</label>' +
    '<select class="form-select form-select-sm action-name-select" onchange="onActionNameChange(' + id + ')"><option value="">-- Action --</option></select></div>' +
    '<div class="col-md-2 action-device-fields"><label class="form-label small">Endpoint</label>' +
    '<input type="number" class="form-control form-control-sm action-device-endpoint-input" value="1" min="1"></div>' +
    '<div class="col-md-4 action-legacy-fields" style="display:none;"><label class="form-label small">Appareil</label>' +
    '<select class="form-select form-select-sm action-legacy-device-select" onchange="onActionLegacyDeviceChange(' + id + ')"><option value="">-- Choisir --</option></select></div>' +
    '<div class="col-md-2 action-legacy-fields" style="display:none;"><label class="form-label small">Endpoint</label>' +
    '<input type="number" class="form-control form-control-sm action-endpoint-input" value="1" min="1"></div>' +
    '<div class="col-md-2 action-legacy-fields" style="display:none;"><label class="form-label small">Valeur</label>' +
    '<select class="form-select form-select-sm action-value-select"><option value="1">ON</option><option value="0">OFF</option><option value="2">TOGGLE</option></select></div>' +
    '<div class="col-md-4 action-notification-fields" style="display:none;"><label class="form-label small">Titre</label>' +
    '<input type="text" class="form-control form-control-sm action-title-input"></div>' +
    '<div class="col-md-4 action-notification-fields" style="display:none;"><label class="form-label small">Message</label>' +
    '<input type="text" class="form-control form-control-sm action-message-input"></div>' +
    '<div class="col-md-12 action-notification-fields" style="display:none;"><div class="form-text small">Variables : {rule} {date} {value} {device} {threshold} {value_N} {device_N}</div></div>' +
    '<div class="col-md-5 action-group-fields" style="display:none;"><label class="form-label small">Groupe d&#39;actions</label>' +
    '<select class="form-select form-select-sm action-group-select"><option value="">-- Choisir --</option></select></div>' +
    '<div class="col-md-12 action-group-fields" style="display:none;"><div class="form-text small">D&eacute;clenche toutes les actions du groupe. <a href="/configActionGroups" target="_blank">G&eacute;rer les groupes</a></div></div>' +
    '<div class="col-md-3 action-dynamic-fields" style="display:none;"><label class="form-label small">Source</label>' +
    '<select class="form-select form-select-sm action-source-device-select" onchange="onActionSourceDeviceChange(' + id + ')"><option value="">-- Source --</option></select></div>' +
    '<div class="col-md-2 action-dynamic-fields" style="display:none;"><label class="form-label small">Cluster</label>' +
    '<select class="form-select form-select-sm action-source-cluster-select" onchange="onActionSourceClusterChange(' + id + ')"><option value="">--</option></select></div>' +
    '<div class="col-md-2 action-dynamic-fields" style="display:none;"><label class="form-label small">Attribut</label>' +
    '<select class="form-select form-select-sm action-source-attribute-select"><option value="">--</option></select></div>' +
    '<div class="col-md-1 action-dynamic-fields" style="display:none;"><label class="form-label small">Coeff</label>' +
    '<input type="number" class="form-control form-control-sm action-coefficient-input" step="any" value="1"></div>' +
    '<div class="col-md-1 action-dynamic-fields" style="display:none;"><label class="form-label small">Offset</label>' +
    '<input type="number" class="form-control form-control-sm action-offset-input" step="any" value="0"></div>' +
    '<div class="col-md-1 d-flex align-items-end"><button type="button" class="btn btn-sm btn-danger" onclick="removeAction(' + id + ')">\u00d7</button></div></div></div></div>';
  $('#actionsContainer').append(html);
  var c = $('[data-action-id="' + id + '"]');
  var sel = c.find('.action-device-select');
  $.each(devices, function(ieee, dev) {
    if (dev.INFO) {
      var actions = getDeviceActions(ieee);
      if (actions.length > 0) {
        var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee.substring(0, 8) + '...)';
        sel.append('<option value="' + ieee + '">' + l + '</option>');
      }
    }
  });
  var selLegacy = c.find('.action-legacy-device-select');
  $.each(devices, function(ieee, dev) {
    if (dev.INFO && hasCluster0006(ieee)) {
      var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee.substring(0, 8) + '...)';
      selLegacy.append('<option value="' + ieee + '">' + l + '</option>');
    }
  });
  var selSource = c.find('.action-source-device-select');
  $.each(devices, function(ieee, dev) {
    if (dev.INFO) {
      var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee.substring(0, 8) + '...)';
      selSource.append('<option value="' + ieee + '">' + l + '</option>');
    }
  });
  var selGroup = c.find('.action-group-select');
  $.each(actionGroupsList, function(i, g) { selGroup.append($('<option>').val(g.name).text(g.name)); });
  onActionTypeChange(id);
  if (data) {
    if (data.type === 'notification') { c.find('.action-type-select').val('notification'); onActionTypeChange(id); c.find('.action-title-input').val(data.title || ''); c.find('.action-message-input').val(data.message || ''); }
    else if (data.type === 'dynamic') {
      c.find('.action-type-select').val('dynamic'); onActionTypeChange(id);
      c.find('.action-device-select').val(data.IEEE); onActionDeviceChange(id);
      setTimeout(function() { c.find('.action-name-select').val(data.actionName); c.find('.action-device-endpoint-input').val(data.endpoint || 1); }, 100);
      c.find('.action-source-device-select').val(data.sourceIEEE); onActionSourceDeviceChange(id);
      setTimeout(function() { c.find('.action-source-cluster-select').val(data.sourceCluster); onActionSourceClusterChange(id); setTimeout(function() { c.find('.action-source-attribute-select').val(data.sourceAttribute); }, 100); }, 100);
      c.find('.action-coefficient-input').val(data.coefficient != null ? data.coefficient : 1);
      c.find('.action-offset-input').val(data.offset != null ? data.offset : 0);
    }
    else if (data.type === 'actiongroup') { c.find('.action-type-select').val('actiongroup'); onActionTypeChange(id); c.find('.action-group-select').val(data.actionName || ''); }
    else if (data.type === 'device' && data.actionName) { c.find('.action-type-select').val('device'); onActionTypeChange(id); c.find('.action-device-select').val(data.IEEE); onActionDeviceChange(id); setTimeout(function() { c.find('.action-name-select').val(data.actionName); c.find('.action-device-endpoint-input').val(data.endpoint || 1); }, 100); }
    else if (data.type === 'onoff') { c.find('.action-type-select').val('onoff'); onActionTypeChange(id); c.find('.action-legacy-device-select').val(data.IEEE); c.find('.action-endpoint-input').val(data.endpoint || 1); c.find('.action-value-select').val(data.value); }
  }
}

function onActionTypeChange(id) {
  var c = $('[data-action-id="' + id + '"]'), t = c.find('.action-type-select').val();
  c.find('.action-device-fields,.action-legacy-fields,.action-notification-fields,.action-dynamic-fields,.action-group-fields').hide();
  c.find('.action-device-select,.action-name-select,.action-device-endpoint-input,.action-legacy-device-select,.action-endpoint-input,.action-value-select,.action-title-input,.action-message-input,.action-source-device-select,.action-source-cluster-select,.action-source-attribute-select,.action-group-select').prop('required', false);
  if (t === 'device') { c.find('.action-device-fields').show(); c.find('.action-device-select,.action-name-select,.action-device-endpoint-input').prop('required', true); }
  else if (t === 'dynamic') { c.find('.action-device-fields,.action-dynamic-fields').show(); c.find('.action-device-select,.action-name-select,.action-device-endpoint-input,.action-source-device-select').prop('required', true); }
  else if (t === 'onoff') { c.find('.action-legacy-fields').show(); c.find('.action-legacy-device-select,.action-endpoint-input,.action-value-select').prop('required', true); }
  else if (t === 'actiongroup') { c.find('.action-group-fields').show(); c.find('.action-group-select').prop('required', true); }
  else { c.find('.action-notification-fields').show(); c.find('.action-title-input,.action-message-input').prop('required', true); }
}

function onActionDeviceChange(id) {
  var c = $('[data-action-id="' + id + '"]'), ieee = c.find('.action-device-select').val(), actionSel = c.find('.action-name-select');
  actionSel.html('<option value="">-- Action --</option>');
  var defaultEp = 1;
  if (ieee && devices[ieee] && devices[ieee].INFO && devices[ieee].INFO.endpoint) { defaultEp = devices[ieee].INFO.endpoint; }
  c.find('.action-device-endpoint-input').val(defaultEp);
  if (!ieee) return;
  var actions = getDeviceActions(ieee);
  actions.forEach(function(act) { if (act.visible !== 0) { actionSel.append('<option value="' + act.name + '" data-endpoint="' + act.endpoint + '">' + act.name + '</option>'); } });
}

function onActionNameChange(id) {
  var c = $('[data-action-id="' + id + '"]'), opt = c.find('.action-name-select option:selected'), ep = opt.data('endpoint');
  if (ep) { c.find('.action-device-endpoint-input').val(ep); }
}

function onActionLegacyDeviceChange(id) {
  var c = $('[data-action-id="' + id + '"]'), ieee = c.find('.action-legacy-device-select').val();
  if (ieee && devices[ieee] && devices[ieee].INFO) { c.find('.action-endpoint-input').val(devices[ieee].INFO.endpoint || '1'); }
}

function onActionSourceDeviceChange(id) {
  var c = $('[data-action-id="' + id + '"]'), ieee = c.find('.action-source-device-select').val(), clSel = c.find('.action-source-cluster-select');
  clSel.html('<option value="">--</option>'); c.find('.action-source-attribute-select').html('<option value="">--</option>');
  if (!ieee || !devices[ieee] || !devices[ieee].INFO) return;
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  var clAdded = {};
  td[0].status.forEach(function(item) { var clStr = item.cluster.toUpperCase(); if (!clAdded[clStr]) { clSel.append('<option value="' + parseInt(clStr, 16) + '">' + clusterLabel(clStr) + '</option>'); clAdded[clStr] = true; } });
}

function onActionSourceClusterChange(id) {
  var c = $('[data-action-id="' + id + '"]'), ieee = c.find('.action-source-device-select').val(), clDec = parseInt(c.find('.action-source-cluster-select').val()), a = c.find('.action-source-attribute-select');
  a.html('<option value="">--</option>');
  if (!ieee || !clDec) return;
  var clHex = ('0000' + clDec.toString(16).toUpperCase()).slice(-4);
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  td[0].status.forEach(function(item) { if (item.cluster.toUpperCase() === clHex) { a.append('<option value="' + item.attribut + '">' + (item.name || item.attribut) + ' (' + item.attribut + ')</option>'); } });
}

function removeAction(id) { $('[data-action-id="' + id + '"]').remove(); buildRuleSummary(); }

// ========== ELSE ACTIONS ==========

function addElseAction(data) {
  var id = elseActionCount++;
  var html = '<div class="card mb-2 else-action-item" data-else-action-id="' + id + '"><div class="card-body"><div class="row g-2">' +
    '<div class="col-md-2"><label class="form-label small">Type</label><select class="form-select form-select-sm else-action-type-select" onchange="onElseActionTypeChange(' + id + ')" required><option value="device">Appareil</option><option value="dynamic">Valeur dynamique</option><option value="actiongroup">Groupe d&#39;actions</option><option value="notification">Notification</option></select></div>' +
    '<div class="col-md-3 else-action-device-fields"><label class="form-label small">Appareil</label><select class="form-select form-select-sm else-action-device-select" onchange="onElseActionDeviceChange(' + id + ')"><option value="">-- Choisir --</option></select></div>' +
    '<div class="col-md-3 else-action-device-fields"><label class="form-label small">Action</label><select class="form-select form-select-sm else-action-name-select" onchange="onElseActionNameChange(' + id + ')"><option value="">-- Action --</option></select></div>' +
    '<div class="col-md-2 else-action-device-fields"><label class="form-label small">Endpoint</label><input type="number" class="form-control form-control-sm else-action-device-endpoint-input" value="1" min="1"></div>' +
    '<div class="col-md-4 else-action-legacy-fields" style="display:none;"><label class="form-label small">Appareil</label><select class="form-select form-select-sm else-action-legacy-device-select" onchange="onElseActionLegacyDeviceChange(' + id + ')"><option value="">-- Choisir --</option></select></div>' +
    '<div class="col-md-2 else-action-legacy-fields" style="display:none;"><label class="form-label small">Endpoint</label><input type="number" class="form-control form-control-sm else-action-endpoint-input" value="1" min="1"></div>' +
    '<div class="col-md-2 else-action-legacy-fields" style="display:none;"><label class="form-label small">Valeur</label><select class="form-select form-select-sm else-action-value-select"><option value="1">ON</option><option value="0">OFF</option><option value="2">TOGGLE</option></select></div>' +
    '<div class="col-md-4 else-action-notification-fields" style="display:none;"><label class="form-label small">Titre</label><input type="text" class="form-control form-control-sm else-action-title-input"></div>' +
    '<div class="col-md-4 else-action-notification-fields" style="display:none;"><label class="form-label small">Message</label><input type="text" class="form-control form-control-sm else-action-message-input"></div>' +
    '<div class="col-md-12 else-action-notification-fields" style="display:none;"><div class="form-text small">Variables : {rule} {date} {value} {device} {threshold} {value_N} {device_N}</div></div>' +
    '<div class="col-md-5 else-action-group-fields" style="display:none;"><label class="form-label small">Groupe d&#39;actions</label>' +
    '<select class="form-select form-select-sm else-action-group-select"><option value="">-- Choisir --</option></select></div>' +
    '<div class="col-md-12 else-action-group-fields" style="display:none;"><div class="form-text small">D&eacute;clenche toutes les actions du groupe. <a href="/configActionGroups" target="_blank">G&eacute;rer les groupes</a></div></div>' +
    '<div class="col-md-3 else-action-dynamic-fields" style="display:none;"><label class="form-label small">Source</label>' +
    '<select class="form-select form-select-sm else-action-source-device-select" onchange="onElseActionSourceDeviceChange(' + id + ')"><option value="">-- Source --</option></select></div>' +
    '<div class="col-md-2 else-action-dynamic-fields" style="display:none;"><label class="form-label small">Cluster</label>' +
    '<select class="form-select form-select-sm else-action-source-cluster-select" onchange="onElseActionSourceClusterChange(' + id + ')"><option value="">--</option></select></div>' +
    '<div class="col-md-2 else-action-dynamic-fields" style="display:none;"><label class="form-label small">Attribut</label>' +
    '<select class="form-select form-select-sm else-action-source-attribute-select"><option value="">--</option></select></div>' +
    '<div class="col-md-1 else-action-dynamic-fields" style="display:none;"><label class="form-label small">Coeff</label>' +
    '<input type="number" class="form-control form-control-sm else-action-coefficient-input" step="any" value="1"></div>' +
    '<div class="col-md-1 else-action-dynamic-fields" style="display:none;"><label class="form-label small">Offset</label>' +
    '<input type="number" class="form-control form-control-sm else-action-offset-input" step="any" value="0"></div>' +
    '<div class="col-md-1 d-flex align-items-end"><button type="button" class="btn btn-sm btn-danger" onclick="removeElseAction(' + id + ')">\u00d7</button></div></div></div></div>';
  $('#elseActionsContainer').append(html);
  var c = $('[data-else-action-id="' + id + '"]'), sel = c.find('.else-action-device-select');
  $.each(devices, function(ieee, dev) {
    if (dev.INFO) {
      var actions = getDeviceActions(ieee);
      if (actions.length > 0) {
        var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee.substring(0, 8) + '...)';
        sel.append('<option value="' + ieee + '">' + l + '</option>');
      }
    }
  });
  var selLegacy = c.find('.else-action-legacy-device-select');
  $.each(devices, function(ieee, dev) {
    if (dev.INFO && hasCluster0006(ieee)) {
      var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee.substring(0, 8) + '...)';
      selLegacy.append('<option value="' + ieee + '">' + l + '</option>');
    }
  });
  var selSource = c.find('.else-action-source-device-select');
  $.each(devices, function(ieee, dev) {
    if (dev.INFO) {
      var m = dev.INFO.model || 'Unknown', a = dev.INFO.alias || '', l = a ? a + ' (' + m + ')' : m + ' (' + ieee.substring(0, 8) + '...)';
      selSource.append('<option value="' + ieee + '">' + l + '</option>');
    }
  });
  var selGroupE = c.find('.else-action-group-select');
  $.each(actionGroupsList, function(i, g) { selGroupE.append($('<option>').val(g.name).text(g.name)); });
  onElseActionTypeChange(id);
  if (data) {
    if (data.type === 'notification') { c.find('.else-action-type-select').val('notification'); onElseActionTypeChange(id); c.find('.else-action-title-input').val(data.title || ''); c.find('.else-action-message-input').val(data.message || ''); }
    else if (data.type === 'dynamic') {
      c.find('.else-action-type-select').val('dynamic'); onElseActionTypeChange(id);
      c.find('.else-action-device-select').val(data.IEEE); onElseActionDeviceChange(id);
      setTimeout(function() { c.find('.else-action-name-select').val(data.actionName); c.find('.else-action-device-endpoint-input').val(data.endpoint || 1); }, 100);
      c.find('.else-action-source-device-select').val(data.sourceIEEE); onElseActionSourceDeviceChange(id);
      setTimeout(function() { c.find('.else-action-source-cluster-select').val(data.sourceCluster); onElseActionSourceClusterChange(id); setTimeout(function() { c.find('.else-action-source-attribute-select').val(data.sourceAttribute); }, 100); }, 100);
      c.find('.else-action-coefficient-input').val(data.coefficient != null ? data.coefficient : 1);
      c.find('.else-action-offset-input').val(data.offset != null ? data.offset : 0);
    }
    else if (data.type === 'actiongroup') { c.find('.else-action-type-select').val('actiongroup'); onElseActionTypeChange(id); c.find('.else-action-group-select').val(data.actionName || ''); }
    else if (data.type === 'device' && data.actionName) { c.find('.else-action-type-select').val('device'); onElseActionTypeChange(id); c.find('.else-action-device-select').val(data.IEEE); onElseActionDeviceChange(id); setTimeout(function() { c.find('.else-action-name-select').val(data.actionName); c.find('.else-action-device-endpoint-input').val(data.endpoint || 1); }, 100); }
    else if (data.type === 'onoff') { c.find('.else-action-type-select').val('onoff'); onElseActionTypeChange(id); c.find('.else-action-legacy-device-select').val(data.IEEE); c.find('.else-action-endpoint-input').val(data.endpoint || 1); c.find('.else-action-value-select').val(data.value); }
  }
}

function onElseActionTypeChange(id) {
  var c = $('[data-else-action-id="' + id + '"]'), t = c.find('.else-action-type-select').val();
  c.find('.else-action-device-fields,.else-action-legacy-fields,.else-action-notification-fields,.else-action-dynamic-fields,.else-action-group-fields').hide();
  c.find('.else-action-device-select,.else-action-name-select,.else-action-device-endpoint-input,.else-action-legacy-device-select,.else-action-endpoint-input,.else-action-value-select,.else-action-title-input,.else-action-message-input,.else-action-source-device-select,.else-action-source-cluster-select,.else-action-source-attribute-select,.else-action-group-select').prop('required', false);
  if (t === 'device') { c.find('.else-action-device-fields').show(); c.find('.else-action-device-select,.else-action-name-select,.else-action-device-endpoint-input').prop('required', true); }
  else if (t === 'dynamic') { c.find('.else-action-device-fields,.else-action-dynamic-fields').show(); c.find('.else-action-device-select,.else-action-name-select,.else-action-device-endpoint-input,.else-action-source-device-select').prop('required', true); }
  else if (t === 'onoff') { c.find('.else-action-legacy-fields').show(); c.find('.else-action-legacy-device-select,.else-action-endpoint-input,.else-action-value-select').prop('required', true); }
  else if (t === 'actiongroup') { c.find('.else-action-group-fields').show(); c.find('.else-action-group-select').prop('required', true); }
  else { c.find('.else-action-notification-fields').show(); c.find('.else-action-title-input,.else-action-message-input').prop('required', true); }
}

function onElseActionDeviceChange(id) {
  var c = $('[data-else-action-id="' + id + '"]'), ieee = c.find('.else-action-device-select').val(), actionSel = c.find('.else-action-name-select');
  actionSel.html('<option value="">-- Action --</option>');
  var defaultEp = 1;
  if (ieee && devices[ieee] && devices[ieee].INFO && devices[ieee].INFO.endpoint) { defaultEp = devices[ieee].INFO.endpoint; }
  c.find('.else-action-device-endpoint-input').val(defaultEp);
  if (!ieee) return;
  var actions = getDeviceActions(ieee);
  actions.forEach(function(act) { if (act.visible !== 0) { actionSel.append('<option value="' + act.name + '" data-endpoint="' + act.endpoint + '">' + act.name + '</option>'); } });
}

function onElseActionNameChange(id) {
  var c = $('[data-else-action-id="' + id + '"]'), opt = c.find('.else-action-name-select option:selected'), ep = opt.data('endpoint');
  if (ep) { c.find('.else-action-device-endpoint-input').val(ep); }
}

function onElseActionLegacyDeviceChange(id) {
  var c = $('[data-else-action-id="' + id + '"]'), ieee = c.find('.else-action-legacy-device-select').val();
  if (ieee && devices[ieee] && devices[ieee].INFO) { c.find('.else-action-endpoint-input').val(devices[ieee].INFO.endpoint || '1'); }
}

function onElseActionSourceDeviceChange(id) {
  var c = $('[data-else-action-id="' + id + '"]'), ieee = c.find('.else-action-source-device-select').val(), clSel = c.find('.else-action-source-cluster-select');
  clSel.html('<option value="">--</option>'); c.find('.else-action-source-attribute-select').html('<option value="">--</option>');
  if (!ieee || !devices[ieee] || !devices[ieee].INFO) return;
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  var clAdded = {};
  td[0].status.forEach(function(item) { var clStr = item.cluster.toUpperCase(); if (!clAdded[clStr]) { clSel.append('<option value="' + parseInt(clStr, 16) + '">' + clusterLabel(clStr) + '</option>'); clAdded[clStr] = true; } });
}

function onElseActionSourceClusterChange(id) {
  var c = $('[data-else-action-id="' + id + '"]'), ieee = c.find('.else-action-source-device-select').val(), clDec = parseInt(c.find('.else-action-source-cluster-select').val()), a = c.find('.else-action-source-attribute-select');
  a.html('<option value="">--</option>');
  if (!ieee || !clDec) return;
  var clHex = ('0000' + clDec.toString(16).toUpperCase()).slice(-4);
  var td = getTemplateData(ieee);
  if (!td || !td[0] || !td[0].status) return;
  td[0].status.forEach(function(item) { if (item.cluster.toUpperCase() === clHex) { a.append('<option value="' + item.attribut + '">' + (item.name || item.attribut) + ' (' + item.attribut + ')</option>'); } });
}

function removeElseAction(id) { $('[data-else-action-id="' + id + '"]').remove(); buildRuleSummary(); }

// ========== LOAD RULE (Edit mode) ==========

function loadRule(rule) {
  $('#oldRuleName').val(rule.name); $('#ruleName').val(rule.name);
  $('#ruleEnabled').prop('checked', rule.enabled !== false);
  if (rule.duration && rule.duration > 0) {
    $('#ruleDuration').val(Math.round(rule.duration / 60));
  }
  if (rule.repeat) { $('#ruleRepeat').val('1'); }
  if (rule.cooldown && rule.cooldown > 0) { $('#ruleCooldown').val(Math.round(rule.cooldown / 60)); }
  if (rule.maxExecPerDay && rule.maxExecPerDay > 0) { $('#ruleMaxExecPerDay').val(rule.maxExecPerDay); }
  if (rule.trigger) {
    $('#triggerMode').val(rule.trigger.mode || 'timer'); onTriggerModeChange();
    if (rule.trigger.mode === 'event') {
      $('#triggerDevice').val(rule.trigger.IEEE); onTriggerDeviceChange();
      setTimeout(function() { $('#triggerCluster').val(rule.trigger.cluster); onTriggerClusterChange(); setTimeout(function() { $('#triggerAttribute').val(rule.trigger.attribute); }, 100); }, 100);
    }
  }
  if (rule.conditions && rule.conditions.length > 0) rule.conditions.forEach(function(c) { addCondition(c); });
  else addCondition();
  if (rule.actions && rule.actions.length > 0) rule.actions.forEach(function(a) { addAction(a); });
  else addAction();
  if (rule.elseActions) rule.elseActions.forEach(function(a) { addElseAction(a); });
}

// ========== RULE SUMMARY ==========

function opToFrench(op) {
  switch (op) {
    case '==': return 'vaut';
    case '!=': return 'ne vaut pas';
    case '<': return 'est inf\u00e9rieur(e) \u00e0';
    case '<=': return 'est inf\u00e9rieur(e) ou \u00e9gal(e) \u00e0';
    case '>': return 'est sup\u00e9rieur(e) \u00e0';
    case '>=': return 'est sup\u00e9rieur(e) ou \u00e9gal(e) \u00e0';
    default: return op;
  }
}

function timeOpToFrench(op, val) {
  switch (op) {
    case '==': return 'il est exactement <b>' + val + '</b>';
    case '!=': return 'il n\'est pas <b>' + val + '</b>';
    case '<': return 'il est avant <b>' + val + '</b>';
    case '<=': return 'il est avant ou \u00e0 <b>' + val + '</b>';
    case '>': return 'il est apr\u00e8s <b>' + val + '</b>';
    case '>=': return 'il est apr\u00e8s ou \u00e0 <b>' + val + '</b>';
    default: return 'heure ' + op + ' ' + val;
  }
}

function formatActionText(c, prefix) {
  var t = c.find('.' + prefix + 'action-type-select').val();
  var p = prefix === 'else-' ? '.else-action-' : '.action-';
  if (t === 'device') {
    var ieee = c.find(p + 'device-select').val();
    var actName = c.find(p + 'name-select').val();
    return 'ex\u00e9cuter <b>' + (actName || '?') + '</b> sur <i>' + getDeviceLabel(ieee) + '</i>';
  } else if (t === 'dynamic') {
    var dIeee = c.find(p + 'device-select').val();
    var dActName = c.find(p + 'name-select').val();
    var sIeee = c.find(p + 'source-device-select').val();
    var coeff = c.find(p + 'coefficient-input').val() || '1';
    var offset = c.find(p + 'offset-input').val() || '0';
    var txt = 'envoyer la valeur de <i>' + getDeviceLabel(sIeee) + '</i>';
    if (coeff !== '1') txt += ' \u00d7' + coeff;
    if (offset !== '0' && offset !== '') txt += (parseFloat(offset) >= 0 ? '+' : '') + offset;
    txt += ' via <b>' + (dActName || '?') + '</b> sur <i>' + getDeviceLabel(dIeee) + '</i>';
    return txt;
  } else if (t === 'onoff') {
    var ieee2 = c.find(p + 'legacy-device-select').val();
    var v = c.find(p + 'value-select').val();
    var vl = v === '1' ? 'allumer' : v === '0' ? '\u00e9teindre' : 'basculer';
    return vl + ' <i>' + getDeviceLabel(ieee2) + '</i>';
  } else if (t === 'notification') {
    var title = c.find(p + 'title-input').val() || '...';
    return 'envoyer la notification \u00ab\u00a0' + title + '\u00a0\u00bb';
  }
  if (t === 'actiongroup') {
    var grp = c.find(p + 'group-select').val();
    // Nom saisi par l'utilisateur : echappe, car le resume est injecte en HTML.
    return 'd\u00e9clencher le groupe d\u2019actions <b>' + (grp ? $('<div>').text(grp).html() : '?') + '</b>';
  }
  return '...';
}

function buildRuleSummary() {
  var condTexts = [];
  var logicOps = [];
  var fullDayNames = ['', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
  var fullMonthNames = ['', 'Janvier', 'F\u00e9vrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Ao\u00fbt', 'Septembre', 'Octobre', 'Novembre', 'D\u00e9cembre'];

  $('#conditionsContainer .condition-item').each(function() {
    var c = $(this), id = c.attr('data-id');
    var type = c.find('.condition-type-select').val();
    var text = '';

    switch (type) {
      case 'device':
        var ieee = c.find('.device-select').val();
        var clDec = parseInt(c.find('.cluster-select').val());
        var atDec = parseInt(c.find('.attribute-select').val());
        var op = c.find('.operator-select').val() || '==';
        var val = c.find('.value-input').val() || '?';
        var devName = getDeviceLabel(ieee);
        var attrName = (!isNaN(clDec) && !isNaN(atDec)) ? getAttributeName(ieee, clDec, atDec) : '...';
        var tplItem = (!isNaN(clDec) && !isNaN(atDec)) ? getTemplateStatusItem(ieee, clDec, atDec) : null;
        var unit = (tplItem && tplItem.unit) ? tplItem.unit : '';
        text = 'la <b>' + attrName + '</b> <i>(' + devName + ')</i> ' + opToFrench(op) + ' <b>' + val + (unit ? ' ' + unit : '') + '</b>';
        break;
      case 'time':
        var tv = c.find('.time-input').val() || '?';
        var top2 = c.find('.operator-select').val() || '==';
        text = timeOpToFrench(top2, tv);
        break;
      case 'time_range':
        var ts = c.find('.time-start-input').val() || '?';
        var te = c.find('.time-end-input').val() || '?';
        var trop = c.find('.operator-select').val() || 'in';
        text = trop === 'in' ? 'l\'heure est entre <b>' + ts + '</b> et <b>' + te + '</b>' : 'l\'heure est en dehors de <b>' + ts + ' - ' + te + '</b>';
        break;
      case 'weekday':
        var days = [];
        c.find('.weekday-check:checked').each(function() { days.push(fullDayNames[$(this).val()]); });
        var wop = c.find('.operator-select').val() || 'in';
        if (days.length === 0) { text = 'le jour est ...'; }
        else if (wop === 'in') { text = 'le jour est ' + (days.length > 1 ? days.slice(0,-1).join(', ') + ' ou ' + days[days.length-1] : days[0]); }
        else { text = 'le jour n\'est pas ' + (days.length > 1 ? days.slice(0,-1).join(', ') + ' ni ' + days[days.length-1] : days[0]); }
        break;
      case 'date':
        var dv = c.find('.date-input').val() || '?';
        var dop = c.find('.operator-select').val() || '==';
        var dateLabel = dv;
        if (dv && dv.indexOf('-') > 0) { var p = dv.split('-'); dateLabel = p[2] + '/' + p[1] + (p[0] ? '/' + p[0] : ''); }
        if (dop === '==') text = 'la date est le <b>' + dateLabel + '</b>';
        else if (dop === '!=') text = 'la date n\'est pas le <b>' + dateLabel + '</b>';
        else if (dop === '<') text = 'la date est avant le <b>' + dateLabel + '</b>';
        else text = 'la date est apr\u00e8s le <b>' + dateLabel + '</b>';
        break;
      case 'day':
        var dayv = c.find('.day-input').val() || '?';
        var dayop = c.find('.operator-select').val() || '==';
        if (dayop === '==') text = 'le jour du mois est le <b>' + dayv + '</b>';
        else if (dayop === '!=') text = 'le jour du mois n\'est pas le <b>' + dayv + '</b>';
        else if (dayop === '<') text = 'le jour du mois est avant le <b>' + dayv + '</b>';
        else text = 'le jour du mois est apr\u00e8s le <b>' + dayv + '</b>';
        break;
      case 'month':
        var mv = c.find('.month-input').val() || '1';
        var mop = c.find('.operator-select').val() || '==';
        var mName = fullMonthNames[parseInt(mv)] || mv;
        if (mop === '==') text = 'le mois est <b>' + mName + '</b>';
        else text = 'le mois n\'est pas <b>' + mName + '</b>';
        break;
      case 'datetime':
        var dtd = c.find('.datetime-date-input').val() || '?';
        var dtt = c.find('.datetime-time-input').val() || '?';
        var dtop = c.find('.operator-select').val() || '==';
        var dtLabel = dtd;
        if (dtd && dtd.indexOf('-') > 0) { var dp = dtd.split('-'); dtLabel = dp[2] + '/' + dp[1] + '/' + dp[0]; }
        dtLabel += ' ' + dtt;
        if (dtop === '==') text = 'la date et heure est exactement <b>' + dtLabel + '</b>';
        else if (dtop === '!=') text = 'la date et heure n\'est pas <b>' + dtLabel + '</b>';
        else if (dtop === '<') text = 'la date et heure est avant <b>' + dtLabel + '</b>';
        else text = 'la date et heure est apr\u00e8s <b>' + dtLabel + '</b>';
        break;
      case 'device_compare':
        var ieee1 = c.find('.device-select').val();
        var cl1 = parseInt(c.find('.cluster-select').val());
        var at1 = parseInt(c.find('.attribute-select').val());
        var ieee2c = c.find('.device2-select').val();
        var cl2 = parseInt(c.find('.cluster2-select').val());
        var at2 = parseInt(c.find('.attribute2-select').val());
        var cop = c.find('.operator-select').val() || '>';
        var coff = c.find('.value-input').val();
        var dn1 = getDeviceLabel(ieee1), dn2 = getDeviceLabel(ieee2c);
        var an1 = (!isNaN(cl1) && !isNaN(at1)) ? getAttributeName(ieee1, cl1, at1) : '...';
        var an2 = (!isNaN(cl2) && !isNaN(at2)) ? getAttributeName(ieee2c, cl2, at2) : '...';
        text = 'la <b>' + an1 + '</b> <i>(' + dn1 + ')</i> ' + opToFrench(cop) + ' la <b>' + an2 + '</b> <i>(' + dn2 + ')</i>';
        if (coff && parseFloat(coff) !== 0) text += ' + <b>' + coff + '</b>';
        break;
    }
    condTexts.push(text || '...');

    var sep = $('[data-for-condition="' + id + '"]');
    logicOps.push(sep.length > 0 ? sep.find('.logic-select').val() : null);
  });

  // Build condition string with natural connectors
  var condStr = '';
  for (var i = 0; i < condTexts.length; i++) {
    if (i > 0 && logicOps[i]) {
      condStr += logicOps[i] === 'OR' ? ' <strong>ou que</strong> ' : ' <strong>et que</strong> ';
    }
    condStr += condTexts[i];
  }

  // Duration text
  var durMin = parseInt($('#ruleDuration').val()) || 0;
  if (durMin > 0) {
    condStr += ' <strong>pendant ' + durMin + ' minute' + (durMin > 1 ? 's' : '') + '</strong>';
  }

  // Mode text
  var isRepeat = $('#ruleRepeat').val() === '1';
  if (isRepeat) {
    var cdMin = parseInt($('#ruleCooldown').val()) || 0;
    condStr += cdMin > 0
      ? ' <em>(r\u00e9p\u00e9t\u00e9 toutes les ' + cdMin + ' min)</em>'
      : ' <em>(\u00e0 chaque \u00e9valuation)</em>';
  }
  var maxExec = parseInt($('#ruleMaxExecPerDay').val()) || 0;
  if (maxExec > 0) {
    condStr += ' <em>(max ' + maxExec + ' fois/jour)</em>';
  }

  // ALORS actions
  var thenTexts = [];
  $('.action-item').each(function() { thenTexts.push(formatActionText($(this), '')); });

  // SINON actions
  var elseTexts = [];
  $('.else-action-item').each(function() { elseTexts.push(formatActionText($(this), 'else-')); });

  var html = '';
  if (condStr) html += '<strong>Si</strong> ' + condStr;
  if (thenTexts.length > 0) html += ', <strong>alors</strong> ' + thenTexts.join(', ');
  if (elseTexts.length > 0) html += ', <strong>sinon</strong> ' + elseTexts.join(', ');
  if (html) html += '.';
  if (!html) html = '<em class="text-muted">Compl\u00e9tez la r\u00e8gle pour voir le r\u00e9sum\u00e9...</em>';

  $('#ruleSummary .card-body').html(html);
}

function updateModeInfo() {
  var isRepeat = $('#ruleRepeat').val() === '1';
  $('#cooldownGroup').toggle(isRepeat);
  var html = isRepeat
    ? '<strong>Mode r\u00e9p\u00e9tition :</strong> Les actions se d\u00e9clenchent <strong>\u00e0 chaque cycle</strong> tant que les conditions sont vraies. Utilisez l\'intervalle minimum pour espacer les ex\u00e9cutions. Les \u00ab\u00a0actions sinon\u00a0\u00bb se d\u00e9clenchent une fois quand les conditions repassent \u00e0 FAUX.'
    : '<strong>Mode changement d\'\u00e9tat :</strong> Les actions ne se d\u00e9clenchent que lors d\'un <strong>changement d\'\u00e9tat</strong> (FAUX \u2192 VRAI). Si les conditions restent vraies, aucune action ne sera r\u00e9-ex\u00e9cut\u00e9e. Les \u00ab\u00a0actions sinon\u00a0\u00bb se d\u00e9clenchent quand les conditions repassent de VRAI \u00e0 FAUX.';
  $('#modeInfoBox').html(html);
  buildRuleSummary();
}
